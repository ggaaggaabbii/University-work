#include "../include/CustomException.h"

CustomException::CustomException()
{

}
