package mvcIntelliJIdea.model;

public class PlayData {
    public Double userId;

    public PlayData() {
        this.userId = Math.random();
    }
}
