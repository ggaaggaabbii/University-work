from ui.ui import start
from tester.tester import *

def main():
	start()

#test_all()
main()
